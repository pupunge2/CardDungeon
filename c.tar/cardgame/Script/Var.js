var canvas;
var context;
var canvasRect;

var scene = 'Title';
var state = '';
var gameType = 'Poker';

var dealer = {
    deck : [],
};

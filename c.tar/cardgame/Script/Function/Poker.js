function determineCardState(card) {
}
